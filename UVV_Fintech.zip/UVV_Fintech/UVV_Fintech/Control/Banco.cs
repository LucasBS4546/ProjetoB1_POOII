﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UVV_Fintech.Model;
using UVV_Fintech.Persistencia;

namespace UVV_Fintech.Control
{
    internal class Banco
    {
        public GerenTransacoes gerenTransacoes = new();
        public GerenConta gerenContas = new();
        public GerenClientes gerenClientes = new();

        public Calendario calendario = new();

        public Banco()
        {
            int idClienteNovo1 = gerenClientes.criarCliente("João Feijão");
            int idCorrenteCliente1 = gerenContas.adicionarContaCorrenteCliente(idClienteNovo1);
            int idPoupancaCliente1 = gerenContas.adicionarContaPoupancaCliente(idClienteNovo1);

            int idClienteNovo2 = gerenClientes.criarCliente("Maria Banana");
            int idCorrenteCliente2 = gerenContas.adicionarContaCorrenteCliente(idClienteNovo2);
            int idPoupancaCliente2 = gerenContas.adicionarContaPoupancaCliente(idClienteNovo2);

            gerenTransacoes.criarTransacaoDeposito(idPoupancaCliente1, 100);
            gerenTransacoes.criarTransacaoDeposito(idPoupancaCliente2, 200);

            gerenTransacoes.criarTransacaoTransferencia(idPoupancaCliente1, idCorrenteCliente1, 50);
            gerenTransacoes.criarTransacaoTransferencia(idCorrenteCliente1, idCorrenteCliente2, 50);

            gerenTransacoes.criarTransacaoSaque(idCorrenteCliente2, 25);

        }
    }
}
