﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVV_Fintech.Model
{
    internal abstract class Conta
    {
        protected static int IdContaCount { get; set; } = 0;
        public int IdConta { get; set; } = IdContaCount;
        public string? TipoConta { get; set; }
        public float Valor { get; set; } = 0;
        public Cliente? Dono { get; set; } = null;

        public string Estado { get; set; } = "Ativa"; // Desativada

        public Conta()
        {
            IdContaCount++;
        }

        public override string? ToString()
        {
            if (this == null) return "";
            return "Id Conta: " + IdConta;

        }
    }
}
