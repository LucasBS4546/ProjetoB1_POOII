﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UVV_Fintech.Control;
using UVV_Fintech.Model;

namespace UVV_Fintech.View
{
    /// <summary>
    /// Lógica interna para ContaAdd.xaml
    /// </summary>
    public partial class ContaAdd : Window
    {
        Banco b;
        internal ContaAdd(Banco banco)
        {
            b = banco;
            InitializeComponent();
        }

        private void ButtonCreateAccount_Click(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrEmpty(TextboxClientId.Text))
            {
                try
                {
                    float valor = String.IsNullOrEmpty(TextboxValue.Text) ? 0 : float.Parse(TextboxValue.Text);
                    if (ComboboxType.SelectedIndex == 0)
                    {
                        b.gerenContas.adicionarContaCorrenteCliente(int.Parse(TextboxClientId.Text), valor);
                    }
                    else if (ComboboxType.SelectedIndex == 1)
                    {
                        b.gerenContas.adicionarContaPoupancaCliente(int.Parse(TextboxClientId.Text), valor);
                    }
                } 
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    TextboxClientId.Clear();
                    TextboxValue.Clear();
                    this.Close();
                }
            }
            
        }
    }
}
