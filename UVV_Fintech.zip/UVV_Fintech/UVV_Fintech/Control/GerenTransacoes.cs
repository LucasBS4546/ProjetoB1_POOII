﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UVV_Fintech.Model;
using UVV_Fintech.Persistencia;

namespace UVV_Fintech.Control
{
    internal class GerenTransacoes()
    {
        public void adicionarTransacao(Transacao t)
        {
            if (t != null)
            {
                BD.adicionarTransacao(t);
                Calendario.adicionarRegistroTransacao(t.IdTrans);
            }
        }

        public BindingList<Transacao> retornaLista() => BD.retornaTransacoes();

        public Transacao? retornaTransacaoPorId(int id)
        {
            if (id >= 0)
            {
                Transacao? t = BD.buscarTransacao(id);
                if (t == null) throw new ArgumentException("Invalid transaction ID", nameof(t));
                return t;
            }
            else
            {
                throw new ArgumentException("Invalid transaction ID");
            }
        }

        public DateTime retornaRegistroTransacaoPorId(int id)
        {
            if (id >= 0)
            {
                Transacao? t = BD.buscarTransacao(id);
                if (t == null) throw new ArgumentException("Invalid transaction ID", nameof(t));
                return Calendario.retornaRegistroTransacaoPorId(id);
            }
            else
            {
                throw new ArgumentException("Invalid transaction ID");
            }
        }

        public int criarTransacaoDeposito(int idConta, float valor)
        {
            Conta? c = new GerenConta().retornaContaPorId(idConta);

            if (c == null)
                throw new ArgumentException("Invalid account id", nameof(c));

            if (c.Estado == "Desativada")
                throw new Exception("Deactivated account cannot make transactions");

            valor = valor < 0 ? 0 : valor;

            Transacao transNova = new Depositar(c, valor);
            adicionarTransacao(transNova);

            return transNova.IdTrans;
        }
        public int criarTransacaoSaque(int idConta, float valor)
        {
            Conta? c = new GerenConta().retornaContaPorId(idConta);

            if (c == null)
                throw new ArgumentException("Invalid account id", nameof(c));

            if (c.Estado == "Desativada")
                throw new Exception("Deactivated account cannot make transactions");

            valor = valor < 0 ? 0 : valor;

            if (c.Valor < valor)
            {
                throw new Exception("Deactivated account cannot make transactions");
            }

            Transacao transNova = new Sacar(c, valor);
            adicionarTransacao(transNova);

            return transNova.IdTrans;
        }
        public int criarTransacaoTransferencia(int idContaPagante, int idContaRecebe, float valor)
        {
            Conta? c1 = new GerenConta().retornaContaPorId(idContaPagante);
            Conta? c2 = new GerenConta().retornaContaPorId(idContaRecebe);

            if (c1 == null)
                throw new ArgumentException("Invalid account id", nameof(c1));
            if (c2 == null)
                throw new ArgumentException("Invalid account id", nameof(c2));

            if (c1.Estado == "Desativada" || c2.Estado == "Desativada")
                return -1;


            valor = valor < 0 ? 0 : valor;

            if (c1.Valor < valor)
            {
                return -1;
            }

            Transacao transNova = new Transferir(c1, c2, valor);
            adicionarTransacao(transNova);

            return transNova.IdTrans;
        }
    }
}
