﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UVV_Fintech.Control;

namespace UVV_Fintech.Model
{
    internal class Transferir : Transacao
    {
        public int IdTrans { get; set; } = Transacao.IdTransCount;
        public float Valor { get; set; }
        public string TipoTrans { get; set; }
        public List<Conta> ContasAfetadas { get; set; } = new();

        public Transferir(Conta contaPagante, Conta contaRecebe, float valor)
        {
            if (contaPagante == null) 
                throw new ArgumentException("Parameter cannot be null", nameof(contaPagante));
            if (contaRecebe == null) 
                throw new ArgumentException("Parameter cannot be null", nameof(contaRecebe));
 
            Transacao.IdTransCount++;
            TipoTrans = "Transferencia";
            ContasAfetadas.Add(contaPagante);
            ContasAfetadas.Add(contaRecebe);
            Valor = valor < 0 ? 0 : valor;
            realizarTransacao();
        }

        public void realizarTransacao()
        {
            GerenConta gerenConta = new();
            gerenConta.removerValorConta(ContasAfetadas[0].IdConta, Valor);
            gerenConta.adicionarValorConta(ContasAfetadas[1].IdConta, Valor);
        }
    }
}
