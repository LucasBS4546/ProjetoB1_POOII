﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace UVV_Fintech.Model
{
    internal class Calendario
    {
        private static Dictionary<int, DateTime> dataTransacoes = new();
        private static Dictionary<int, DateTime> dataContas = new();
        private static Dictionary<int, DateTime> dataClientes = new();

        public static void adicionarRegistroTransacao(int idTransacao) => dataTransacoes.Add(idTransacao, DateTime.Now);
        public static void adicionarRegistroConta(int idConta) => dataContas.Add(idConta, DateTime.Now);
        public static void adicionarRegistroCliente(int idCliente) => dataClientes.Add(idCliente, DateTime.Now);

        public static DateTime retornaRegistroTransacaoPorId(int idTransacao) => dataTransacoes[idTransacao];
        public static DateTime retornaRegistroContaPorId(int idConta) => dataContas[idConta];
        public static DateTime retornaRegistroClientePorId(int idCliente) => dataClientes[idCliente];
    }
}
