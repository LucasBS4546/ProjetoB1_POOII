﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UVV_Fintech.Control;

namespace UVV_Fintech.View
{
    /// <summary>
    /// Lógica interna para ClienteDeactivate.xaml
    /// </summary>
    public partial class ClienteDeactivate : Window
    {
        Banco b;
        internal ClienteDeactivate(Banco banco)
        {
            b = banco;
            InitializeComponent();
        }


        private void ButtonDeactivateClient_Click(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrEmpty(TextboxClientId.Text))
            {
                try
                {
                    b.gerenClientes.desativarClientePorId(int.Parse(TextboxClientId.Text));
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            TextboxClientId.Clear();
            this.Close();
        }
    }
}
