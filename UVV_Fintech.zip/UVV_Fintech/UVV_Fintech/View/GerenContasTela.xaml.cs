﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UVV_Fintech.Control;

namespace UVV_Fintech.View
{
    /// <summary>
    /// Lógica interna para GerenContasTela.xaml
    /// </summary>
    public partial class GerenContasTela : Window
    {
        Banco b;
        internal GerenContasTela(Banco banco)
        {
            InitializeComponent();
            b = banco;
            DatagridListaContas.ItemsSource = banco.gerenContas.retornaLista().Select((c) =>

                new { c.IdConta, c.TipoConta, c.Valor, c.Dono.Nome, c.Estado }

            );
        }

        private void ButtonAddAccount_Click(object sender, RoutedEventArgs e)
        {
            new ContaAdd(b).ShowDialog();
        }

        private void ButtonDeactivateAccount_Click(object sender, RoutedEventArgs e)
        {
            new ContaDeactivate(b).ShowDialog();
        }
    }
}
