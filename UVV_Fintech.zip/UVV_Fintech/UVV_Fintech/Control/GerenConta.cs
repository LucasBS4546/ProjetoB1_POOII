﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UVV_Fintech.Model;
using UVV_Fintech.Persistencia;

namespace UVV_Fintech.Control
{
    internal class GerenConta()
    {
        public void adicionarConta(Conta c)
        {
            if (c != null)
            {
                BD.adicionarConta(c);
                Calendario.adicionarRegistroConta(c.IdConta);
            }
        }

        public BindingList<Conta> retornaLista() => BD.retornaContas();

        public void desativarContaPorId(int id)
        {
            Conta? conta = retornaContaPorId(id);
            if (conta == null) throw new ArgumentException("Invalid ID", nameof(conta));
            BD.desativarConta(conta);
        }

        public void desativarConta(Conta conta)
        {
            if (conta == null) throw new ArgumentException("Invalid ID", nameof(conta));
            BD.desativarConta(conta);
        }

        public int adicionarContaCorrenteCliente(int idCliente, float valor = 0)
        {
            Cliente? clienteDono = new GerenClientes().retornaClientePorId(idCliente);
            if (clienteDono == null) throw new Exception("Client is null");
            if (clienteDono.Estado == "Desativado") throw new Exception("Client ID is of deactivated client");

            Conta contaNova = new ContaCorrente();
            contaNova.Dono = clienteDono;
            contaNova.Valor = valor >= 0 ? valor : 0;

            adicionarConta(contaNova);

            return contaNova.IdConta;
        }
        public int adicionarContaPoupancaCliente(int idCliente, float valor = 0)
        {

            Cliente? clienteDono = new GerenClientes().retornaClientePorId(idCliente);
            if (clienteDono == null) throw new Exception("Client is null");
            if (clienteDono.Estado == "Desativado") throw new Exception("Client ID is of deactivated client");

            Conta contaNova = new Poupanca();
            contaNova.Dono = clienteDono;
            contaNova.Valor = valor >= 0 ? valor : 0;

            adicionarConta(contaNova);

            return contaNova.IdConta;
        }

        public Conta? retornaContaPorId(int id)
        {
            if (id >= 0)
            {
                Conta? c = BD.buscarConta(id);
                if (c == null) throw new ArgumentException("Invalid account ID", nameof(c));
                return c;
            }
            else
            {
                throw new ArgumentException("Invalid account ID");
            }
        }

        public List<Conta> retornaContasPorDono(Cliente cliente)
        { 
            List<Conta> contas = new();
            foreach (var conta in BD.retornaContas())
            {
                if (conta.Dono == cliente)
                {
                    contas.Add(conta);
                }
            }
            return contas;
        }

        public DateTime retornaRegistroContaPorId(int id)
        {
            if (id >= 0)
            {
                Conta? c = BD.buscarConta(id);
                if (c == null) throw new ArgumentException("Invalid account ID", nameof(c));
                return Calendario.retornaRegistroContaPorId(id);
            }
            else
            {
                throw new ArgumentException("Invalid account ID");
            }
        }

        public void adicionarValorConta(int id, float v)
        {
            if (id >= 0)
            {
                Conta? c = BD.buscarConta(id) ?? throw new Exception("Invalid id - account does not exit");
                BD.adicionarValorConta(c, v);
            }
            else
            {
                throw new ArgumentException("Invalid id - negative id", nameof(id));
            }
        }

        public void removerValorConta(int id, float v)
        {
            if (id >= 0)
            {
                Conta? c = BD.buscarConta(id) ?? throw new Exception("Invalid id - account does not exit");
                BD.subtrairValorConta(c, v);
            }
            else
            {
                throw new ArgumentException("Invalid id - negative id", nameof(id));
            }
        }

    }
}
