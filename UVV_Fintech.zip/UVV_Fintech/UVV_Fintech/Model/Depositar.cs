﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UVV_Fintech.Control;

namespace UVV_Fintech.Model
{
    internal class Depositar : Transacao
    {
        public int IdTrans { get; set; } = Transacao.IdTransCount;
        public float Valor { get; set; } = 0;
        public string TipoTrans { get; set; }
        public List<Conta> ContasAfetadas { get; set; } = new();

        public Depositar(Conta contaAfetada, float valor)
        {
            if (contaAfetada == null)
                throw new ArgumentException("Parameter cannot be null", nameof(contaAfetada));

            Transacao.IdTransCount++;
            TipoTrans = "Deposito";
            ContasAfetadas.Add(contaAfetada);
            Valor = valor < 0 ? 0 : valor;
            realizarTransacao();
        }

        public void realizarTransacao()
        {
            GerenConta gerenConta = new();
            gerenConta.adicionarValorConta(ContasAfetadas[0].IdConta, Valor);
        }
    }
}
