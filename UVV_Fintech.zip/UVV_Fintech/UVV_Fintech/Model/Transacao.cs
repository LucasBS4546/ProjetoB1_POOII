﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVV_Fintech.Model
{
    internal interface Transacao
    {
        protected static int IdTransCount { get; set; } = 0;
        public int IdTrans { get; set; }
        public float Valor {  get; set; }
        public string TipoTrans { get; set; }
        public List<Conta> ContasAfetadas { get; set; }

        public abstract void realizarTransacao();

    }
}
