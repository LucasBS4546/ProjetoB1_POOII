﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UVV_Fintech.Model;
using UVV_Fintech.Persistencia;

namespace UVV_Fintech.Control
{
    internal class GerenConta()
    {
        public void adicionarConta(Conta c)
        {
            if (c != null)
            {
                BD.adicionarConta(c);
            }
        }

        public BindingList<Conta> retornaLista() => BD.retornaContas();

        public void desativarContaPorId(int id)
        {
            Conta? conta = retornaContaPorId(id);
            if (conta == null) throw new ArgumentException("Invalid ID", nameof(conta));
            BD.desativarConta(conta);
        }

        public void desativarConta(Conta conta)
        {
            if (conta == null) throw new ArgumentException("Invalid ID", nameof(conta));
            BD.desativarConta(conta);
        }

        public int adicionarContaCorrenteCliente(int idCliente, float valor = 0)
        {
            Conta contaNova = new ContaCorrente();

            contaNova.Valor = valor >= 0 ? valor : 0;

            contaNova.Dono = new GerenClientes().retornaClientePorId(idCliente);
            if (contaNova.Dono.Estado == "Desativado")
            {
                throw new Exception("Client ID is of deactivated client");
            }

            adicionarConta(contaNova);

            return contaNova.IdConta;
        }
        public int adicionarContaPoupancaCliente(int idCliente, float valor = 0)
        {
            Conta contaNova = new Poupanca();

            contaNova.Valor = valor >= 0 ? valor : 0;

            contaNova.Dono = new GerenClientes().retornaClientePorId(idCliente);
            if (contaNova.Dono.Estado == "Desativado")
            {
                throw new Exception("Client ID is of deactivated client");
            }

            adicionarConta(contaNova);

            return contaNova.IdConta;
        }

        public Conta? retornaContaPorId(int id)
        {
            if (id >= 0)
            {
                return BD.buscarConta(id);
            }
            else
            {
                return null;
            }
        }

        public List<Conta> retornaContasPorDono(Cliente cliente)
        { 
            List<Conta> contas = new();
            foreach (var conta in BD.retornaContas())
            {
                if (conta.Dono == cliente)
                {
                    contas.Add(conta);
                }
            }
            return contas;
        }

        public void adicionarValorConta(int id, float v)
        {
            if (id >= 0)
            {
                Conta? c = BD.buscarConta(id) ?? throw new Exception("Invalid id - account does not exit");
                BD.adicionarValorConta(c, v);
            }
            else
            {
                throw new ArgumentException("Invalid id - negative id", nameof(id));
            }
        }

        public void removerValorConta(int id, float v)
        {
            if (id >= 0)
            {
                Conta? c = BD.buscarConta(id) ?? throw new Exception("Invalid id - account does not exit");
                BD.subtrairValorConta(c, v);
            }
            else
            {
                throw new ArgumentException("Invalid id - negative id", nameof(id));
            }
        }

    }
}
