﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UVV_Fintech.Control;

namespace UVV_Fintech.View
{
    /// <summary>
    /// Lógica interna para TransSaqueAdd.xaml
    /// </summary>
    public partial class TransSaqueAdd : Window
    {
        Banco b;
        internal TransSaqueAdd(Banco banco)
        {
            b = banco;
            InitializeComponent();
        }

        private void ButtonCreateSaque_Click(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrEmpty(TextboxAccountId.Text))
            {
                float valor = String.IsNullOrEmpty(TextboxValue.Text) ? 0 : float.Parse(TextboxValue.Text);
                try
                {
                    b.gerenTransacoes.criarTransacaoSaque(int.Parse(TextboxAccountId.Text), valor);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    TextboxAccountId.Clear();
                    TextboxValue.Clear();
                }
            }
        }
    }
}
