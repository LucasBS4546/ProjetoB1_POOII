﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Navigation;
using UVV_Fintech.Model;
using UVV_Fintech.Persistencia;

namespace UVV_Fintech.Control
{
    internal class GerenClientes()
    {
        public void adicionarCliente(Cliente c)
        {
            if (c != null)
            {
                BD.adicionarCliente(c);
            }
        }

        public int criarCliente(string nome)
        {
            Cliente clienteNovo = new();
            clienteNovo.Nome = nome;

            adicionarCliente(clienteNovo);

            return clienteNovo.IdCliente;
        }

        public void desativarClientePorId(int id)
        {
            Cliente? cliente = retornaClientePorId(id);
            if (cliente == null) throw new ArgumentException("Invalid ID", nameof(cliente));

            BD.desativarCliente(cliente);

            GerenConta gerenConta = new();

            List<Conta> contas = gerenConta.retornaContasPorDono(cliente);
            if (contas != null)
            {
                foreach(Conta conta in contas)
                {
                    gerenConta.desativarConta(conta);
                }
            }
        }

        public BindingList<Cliente> retornaLista() => BD.retornaClientes();

        public Cliente? retornaClientePorId(int id)
        {
            if (id >= 0)
            {
                Cliente? c = BD.buscarCliente(id);
                if (c == null) throw new ArgumentException("Invalid client ID", nameof(c));
                return c;
            } else
            {
                throw new ArgumentException("Invalid client ID");
            }
        }
    }
}
