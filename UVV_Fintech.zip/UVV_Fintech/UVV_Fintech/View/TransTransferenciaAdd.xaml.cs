﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UVV_Fintech.Control;

namespace UVV_Fintech.View
{
    /// <summary>
    /// Lógica interna para TransTransferenciaAdd.xaml
    /// </summary>
    public partial class TransTransferenciaAdd : Window
    {
        Banco b;
        internal TransTransferenciaAdd(Banco banco)
        {
            b = banco;
            InitializeComponent();
        }

        private void ButtonCreateTransfer_Click(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrEmpty(TextboxAccountPayerId.Text) && !String.IsNullOrEmpty(TextboxAccountReceiverId.Text))
            {
                float valor = String.IsNullOrEmpty(TextboxValue.Text) ? 0 : float.Parse(TextboxValue.Text);
                try
                {
                    b.gerenTransacoes.criarTransacaoTransferencia(
                                                                    int.Parse(TextboxAccountPayerId.Text),
                                                                    int.Parse(TextboxAccountReceiverId.Text),
                                                                    valor
                                                                 );
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    TextboxAccountPayerId.Clear();
                    TextboxAccountReceiverId.Clear();
                    TextboxValue.Clear();
                }
            }
        }
    }
}
