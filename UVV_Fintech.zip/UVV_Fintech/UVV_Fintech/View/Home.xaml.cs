﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UVV_Fintech.Control;

namespace UVV_Fintech.View
{
    /// <summary>
    /// Lógica interna para Home.xaml
    /// </summary>
    public partial class Home : Window
    {

        Banco bancoXurupita = new();

        public Home()
        {
            InitializeComponent();
        }

        private void ButtonGerenTransacoes_Click(object sender, RoutedEventArgs e)
        {
            GerenTransTela telaTrans = new(bancoXurupita);
            telaTrans.ShowDialog();
        }

        private void ButtonGerenContas_Click(object sender, RoutedEventArgs e)
        {
            GerenContasTela telaContas = new(bancoXurupita);
            telaContas.ShowDialog();
        }

        private void ButtonGerenClientes_Click(object sender, RoutedEventArgs e)
        {
            GerenClienteTela telaClientes = new(bancoXurupita);
            telaClientes.ShowDialog();
        }
    }
}
