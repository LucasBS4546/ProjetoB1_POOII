﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace UVV_Fintech.Model
{
    internal class Calendario
    {

    }
}
