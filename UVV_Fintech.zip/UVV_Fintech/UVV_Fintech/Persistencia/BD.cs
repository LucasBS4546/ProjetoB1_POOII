﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UVV_Fintech.Model;

namespace UVV_Fintech.Persistencia
{
    internal class BD
    {
        private static BindingList<Cliente> listaClientes = new();
        private static BindingList<Transacao> listaTransacoes = new();
        private static BindingList<Conta> listaContas = new();


        public static void adicionarCliente(Cliente c) => listaClientes.Add(c);
        public static void adicionarTransacao(Transacao t) => listaTransacoes.Add(t);
        public static void adicionarConta(Conta c) => listaContas.Add(c);

        public static Cliente? buscarCliente(int id) {
            Cliente? c = null;
            foreach (var cliente in listaClientes)
            {
                if (cliente.IdCliente == id)
                {
                    c = cliente;
                }
            }
            return c;
        }
        public static Transacao? buscarTransacao(int id)
        {
            Transacao? t = null;
            foreach (var trans in listaTransacoes)
            {
                if (trans.IdTrans == id)
                {
                    t = trans;
                }
            }
            return t;
        }
        public static Conta? buscarConta(int id)
        {
            Conta? c = null;
            foreach (var conta in listaContas)
            {
                if (conta.IdConta == id)
                {
                    c = conta;
                }
            }
            return c;
        }

        public static void desativarCliente(Cliente c) => c.Estado = "Desativado";
        public static void desativarConta(Conta c) => c.Estado = "Desativada";

        public static void adicionarValorConta(Conta c, float valor) => c.Valor += valor;
        public static void subtrairValorConta(Conta c, float valor) => c.Valor -= valor;

        public static BindingList<Cliente> retornaClientes() => listaClientes;
        public static BindingList<Transacao> retornaTransacoes() => listaTransacoes;
        public static BindingList<Conta> retornaContas() => listaContas;
    }
}
