﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UVV_Fintech.Control;

namespace UVV_Fintech.View
{
    public partial class GerenClienteTela : Window
    {
        Banco b;
        internal GerenClienteTela(Banco banco)
        {
            InitializeComponent();
            b = banco;
            DatagridListaClientes.ItemsSource = b.gerenClientes.retornaLista();
        }

        private void ButtonAddClient_Click(object sender, RoutedEventArgs e)
        {
            new ClienteAdd(b).ShowDialog();
        }

        private void ButtonDeactivateClient_Click(object sender, RoutedEventArgs e)
        {
            new ClienteDeactivate(b).ShowDialog();
        }
    }
}
