﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UVV_Fintech.Control;

namespace UVV_Fintech.View
{
    /// <summary>
    /// Lógica interna para GerenTransTela.xaml
    /// </summary>
    public partial class GerenTransTela : Window
    {
        Banco b;
        internal GerenTransTela(Banco banco)
        {
            b = banco;
            InitializeComponent();
            loadDatagrid();
        }

        private void ButtonAddDeposito_Click(object sender, RoutedEventArgs e)
        {
            new TransDepositoAdd(b).ShowDialog();
            loadDatagrid();
        }

        private void ButtonAddSaque_Click(object sender, RoutedEventArgs e)
        {
            new TransSaqueAdd(b).ShowDialog();
            loadDatagrid();
        }

        private void ButtonAddTransferencia_Click(object sender, RoutedEventArgs e)
        {
            new TransTransferenciaAdd(b).ShowDialog();
            loadDatagrid();
        }

        private void loadDatagrid()
        {
            DatagridListaTrans.ItemsSource = b.gerenTransacoes.retornaLista().Select((t) =>

                new {
                    t.IdTrans,
                    t.TipoTrans,
                    t.Valor,
                    ContaAfetada1 = t.ContasAfetadas[0].ToString(),
                    ContaAfetada2 = t.TipoTrans == "Transferencia" ? t.ContasAfetadas[1].ToString() : "",
                    DataDaTransacao = b.gerenTransacoes.retornaRegistroTransacaoPorId(t.IdTrans)
                }

            );
        }
    }
}
