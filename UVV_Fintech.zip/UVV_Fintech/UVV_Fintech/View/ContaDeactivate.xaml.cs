﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UVV_Fintech.Control;

namespace UVV_Fintech.View
{
    /// <summary>
    /// Lógica interna para ContaDeactivate.xaml
    /// </summary>
    public partial class ContaDeactivate : Window
    {
        Banco b;
        internal ContaDeactivate(Banco banco)
        {
            b = banco;
            InitializeComponent();
        }

        private void ButtonDeactivateAccount_Click(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrEmpty(TextboxAccountId.Text))
            {
                try
                {
                    b.gerenContas.desativarContaPorId(int.Parse(TextboxAccountId.Text));
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            TextboxAccountId.Clear();
        }
    }
}
